from django.apps import AppConfig


class TokenizerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tokenizer'
